import pygame
import random
import os
import sys


pygame.init()
pygame.mixer.init()
screen = pygame.display.set_mode((800, 600))
pygame.display.set_caption("Juego definitivo MIGUEL CARO")
clock = pygame.time.Clock()


WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
YELLOW = (255, 255, 0)
GRAY = (150, 150, 150)
LIGHT_BLUE = (100, 100, 255)


MENU_PRINCIPAL = 0
MENU_JUEGO = 1
MENU_SKIN = 2
MENU_MUSICA = 3
JUGANDO = 4
GAME_OVER = 5


estado_actual = MENU_PRINCIPAL
juego_seleccionado = None
skin_seleccionada = 0
musica_seleccionada = 0
puntuacion = 0
intentos = 0
nivel_dificultad = 1

try:
    fondo = pygame.image.load("assets/fondo.jpg")
    fondo = pygame.transform.scale(fondo, (800, 600))
    
    skins = [
        pygame.image.load("assets/skin1.png"),
        pygame.image.load("assets/skin2.png"),
        pygame.image.load("assets/skin3.png")
    ]
    
    for i in range(len(skins)):
        skins[i] = pygame.transform.scale(skins[i], (50, 50))
    
    canciones = [
        "assets/cancion1.mp3",
        "assets/cancion2.mp3",
        "assets/cancion3.mp3"
    ]

except Exception as e:
    print("Error al cargar recursos. Asegúrate de tener los archivos necesarios en la carpeta.")
    print(f"Detalles: {e}")
    
    fondo = pygame.Surface((800, 600))
    fondo.fill((50, 50, 100))
    
    skins = []
    for i in range(3):
        surf = pygame.Surface((50, 50), pygame.SRCALPHA)
        color = [(255, 0, 0), (0, 255, 0), (0, 0, 255)][i]
        pygame.draw.rect(surf, color, (0, 0, 50, 50))
        pygame.draw.circle(surf, (255, 255, 255), (25, 25), 15)
        skins.append(surf)
    
    # Aseguramos que canciones exista aunque no se puedan cargar
    canciones = []



font_large = pygame.font.SysFont(None, 72)
font_medium = pygame.font.SysFont(None, 48)
font_small = pygame.font.SysFont(None, 36)


def dibujar_texto(texto, fuente, color, x, y, centrado=True):
    texto_surface = fuente.render(texto, True, color)
    texto_rect = texto_surface.get_rect()
    if centrado:
        texto_rect.center = (x, y)
    else:
        texto_rect.topleft = (x, y)
    screen.blit(texto_surface, texto_rect)
    return texto_rect


def dibujar_boton(texto, x, y, ancho, alto, color_normal, color_hover, mouse_pos):
    boton_rect = pygame.Rect(x - ancho//2, y - alto//2, ancho, alto)
    
    if boton_rect.collidepoint(mouse_pos):
        pygame.draw.rect(screen, color_hover, boton_rect, border_radius=10)
    else:
        pygame.draw.rect(screen, color_normal, boton_rect, border_radius=10)
    
    pygame.draw.rect(screen, BLACK, boton_rect, 2, border_radius=10)
    dibujar_texto(texto, font_medium, BLACK, x, y)
    
    return boton_rect


def reproducir_musica():
    try:
        pygame.mixer.music.load(canciones[musica_seleccionada])
        pygame.mixer.music.play(-1) 
    except:
        print(f"No se pudo cargar la música: {canciones[musica_seleccionada]}")


def juego_evasion():
    global estado_actual, puntuacion, intentos
    
    
    if nivel_dificultad == 1: 
        enemy_speed = 2
        spawn_rate = 20
    elif nivel_dificultad == 2: 
        enemy_speed = 3
        spawn_rate = 15
    else:  
        enemy_speed = 4
        spawn_rate = 10
    
    
    player_size = 50
    player_x = 400
    player_y = 500
    player_speed = 5
    
    
    enemies = []
    enemy_size = 30
    
    
    tiempo_inicio = pygame.time.get_ticks()
    tiempo_juego = 0
    
    running = True
    while running:
        tiempo_actual = pygame.time.get_ticks()
        tiempo_juego = (tiempo_actual - tiempo_inicio) // 1000 
        puntuacion = tiempo_juego * 10  
        
        screen.blit(fondo, (0, 0))
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                    estado_actual = MENU_PRINCIPAL
                    return
        
        
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and player_x > 0:
            player_x -= player_speed
        if keys[pygame.K_RIGHT] and player_x < 800 - player_size:
            player_x += player_speed
        
        
        if random.randint(1, spawn_rate) == 1:
            enemies.append([random.randint(0, 800 - enemy_size), 0])
        
        
        for enemy in enemies[:]:
            enemy[1] += enemy_speed
            if enemy[1] > 600:
                enemies.remove(enemy)
            else:
                pygame.draw.rect(screen, RED, (enemy[0], enemy[1], enemy_size, enemy_size))
            
           
            if (player_x < enemy[0] + enemy_size and
                player_x + player_size > enemy[0] and
                player_y < enemy[1] + enemy_size and
                player_y + player_size > enemy[1]):
                intentos += 1
                running = False
                estado_actual = GAME_OVER
        
        
        screen.blit(skins[skin_seleccionada], (player_x, player_y))
        
        
        dibujar_texto(f"Puntos: {puntuacion}", font_small, WHITE, 700, 30)
        dibujar_texto(f"Tiempo: {tiempo_juego}s", font_small, WHITE, 100, 30)
        
        pygame.display.update()
        clock.tick(60)

def juego_recoleccion():
    global estado_actual, puntuacion, intentos

    if nivel_dificultad == 1:  
        item_speed = 0
        spawn_rate = 30
        tiempo_limite = 60
    elif nivel_dificultad == 2:  
        item_speed = 1
        spawn_rate = 25
        tiempo_limite = 45
    else:  
        item_speed = 2
        spawn_rate = 20
        tiempo_limite = 30

    player_size = 40
    player_x = 400
    player_y = 300
    player_speed = 5

    items = []
    item_size = 20

    tiempo_inicio = pygame.time.get_ticks()
    tiempo_restante = tiempo_limite

    running = True
    while running:
        tiempo_actual = pygame.time.get_ticks()
        tiempo_transcurrido = (tiempo_actual - tiempo_inicio) // 1000
        tiempo_restante = max(0, tiempo_limite - tiempo_transcurrido)

        if tiempo_restante == 0:
            intentos += 1
            running = False
            estado_actual = GAME_OVER

        screen.blit(fondo, (0, 0))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                    estado_actual = MENU_PRINCIPAL
                    return

        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and player_x > 0:
            player_x -= player_speed
        if keys[pygame.K_RIGHT] and player_x < 800 - player_size:
            player_x += player_speed
        if keys[pygame.K_UP] and player_y > 0:
            player_y -= player_speed
        if keys[pygame.K_DOWN] and player_y < 600 - player_size:
            player_y += player_speed

        if random.randint(1, spawn_rate) == 1:
            items.append([random.randint(0, 800 - item_size), random.randint(0, 600 - item_size), 0])  

        for item in items[:]:
            item[2] += 0.1
            offset_y = math.sin(item[2]) * 3
            item[1] += item_speed

            if item[1] > 600:
                items.remove(item)
                continue

            pygame.draw.rect(screen, YELLOW, (item[0], item[1] + offset_y, item_size, item_size))

            if (player_x < item[0] + item_size and
                player_x + player_size > item[0] and
                player_y < item[1] + item_size + offset_y and
                player_y + player_size > item[1] + offset_y):
                items.remove(item)
                puntuacion += 10 * nivel_dificultad

        screen.blit(skins[skin_seleccionada], (player_x, player_y))
        dibujar_texto(f"Puntos: {puntuacion}", font_small, WHITE, 700, 30)
        dibujar_texto(f"Tiempo: {tiempo_restante}s", font_small, WHITE, 100, 30)

        pygame.display.update()
        clock.tick(60)



def juego_disparos():
    global estado_actual, puntuacion, intentos
    
   
    if nivel_dificultad == 1:
        enemy_speed = 2
        bullet_speed = 7
        spawn_rate = 30
    elif nivel_dificultad == 2: 
        enemy_speed = 3
        bullet_speed = 6
        spawn_rate = 25
    else:  
        enemy_speed = 4
        bullet_speed = 5
        spawn_rate = 20
    
    
    player_size = 50
    player_x = 400
    player_y = 500
    player_speed = 5
    
    
    bullets = []
    
    
    enemies = []
    enemy_size = 40
    
    
    vidas = 5
    
    running = True
    while running:
        screen.blit(fondo, (0, 0))
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                    estado_actual = MENU_PRINCIPAL
                    return
                if event.key == pygame.K_SPACE:
                    bullets.append([player_x + player_size//2 - 2, player_y])
        
        
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and player_x > 0:
            player_x -= player_speed
        if keys[pygame.K_RIGHT] and player_x < 800 - player_size:
            player_x += player_speed
        
        
        if random.randint(1, spawn_rate) == 1:
            enemies.append([random.randint(0, 800 - enemy_size), 0])
        
        
        for enemy in enemies[:]:
            enemy[1] += enemy_speed
            if enemy[1] > 600:
                enemies.remove(enemy)
                vidas -= 1
                if vidas <= 0:
                    intentos += 1
                    running = False
                    estado_actual = GAME_OVER
            else:
                pygame.draw.circle(screen, RED, (enemy[0] + enemy_size//2, enemy[1] + enemy_size//2), enemy_size//2)
        
        
        for bullet in bullets[:]:
            bullet[1] -= bullet_speed
            if bullet[1] < 0:
                bullets.remove(bullet)
            else:
                pygame.draw.rect(screen, BLACK, (bullet[0], bullet[1], 5, 10))
        
        
        for bullet in bullets[:]:
            for enemy in enemies[:]:
                if (bullet[0] < enemy[0] + enemy_size and
                    bullet[0] + 5 > enemy[0] and
                    bullet[1] < enemy[1] + enemy_size and
                    bullet[1] + 10 > enemy[1]):
                    if bullet in bullets:
                        bullets.remove(bullet)
                    if enemy in enemies:
                        enemies.remove(enemy)
                    puntuacion += 20 * nivel_dificultad
        
        
        screen.blit(skins[skin_seleccionada], (player_x, player_y))
        
        
        dibujar_texto(f"Puntos: {puntuacion}", font_small, WHITE, 700, 30)
        dibujar_texto(f"Vidas: {vidas}", font_small, WHITE, 100, 30)
        
        pygame.display.update()
        clock.tick(60)


import math  
while True:
    mouse_pos = pygame.mouse.get_pos()
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1: 
                if estado_actual == MENU_PRINCIPAL:
                    
                    if juego1_rect.collidepoint(mouse_pos):
                        juego_seleccionado = 1
                        estado_actual = MENU_SKIN
                    elif juego2_rect.collidepoint(mouse_pos):
                        juego_seleccionado = 2
                        estado_actual = MENU_SKIN
                    elif juego3_rect.collidepoint(mouse_pos):
                        juego_seleccionado = 3
                        estado_actual = MENU_SKIN
                
                elif estado_actual == MENU_SKIN:
                    
                    for i in range(3):
                        if skin_rects[i].collidepoint(mouse_pos):
                            skin_seleccionada = i
                            estado_actual = MENU_MUSICA
                    
                    
                    if volver_rect.collidepoint(mouse_pos):
                        estado_actual = MENU_PRINCIPAL
                
                elif estado_actual == MENU_MUSICA:
                    
                    for i in range(3):
                        if musica_rects[i].collidepoint(mouse_pos):
                            musica_seleccionada = i
                            reproducir_musica()
                            estado_actual = MENU_JUEGO
                    
                    
                    if volver_rect.collidepoint(mouse_pos):
                        estado_actual = MENU_SKIN
                
                elif estado_actual == MENU_JUEGO:
                    
                    if facil_rect.collidepoint(mouse_pos):
                        nivel_dificultad = 1
                        estado_actual = JUGANDO
                        puntuacion = 0
                    elif medio_rect.collidepoint(mouse_pos):
                        nivel_dificultad = 2
                        estado_actual = JUGANDO
                        puntuacion = 0
                    elif dificil_rect.collidepoint(mouse_pos):
                        nivel_dificultad = 3
                        estado_actual = JUGANDO
                        puntuacion = 0
                    
                    
                    if volver_rect.collidepoint(mouse_pos):
                        estado_actual = MENU_MUSICA
                
                elif estado_actual == GAME_OVER:
                    
                    if jugar_rect.collidepoint(mouse_pos):
                        estado_actual = MENU_JUEGO
                    
                    
                    if menu_rect.collidepoint(mouse_pos):
                        estado_actual = MENU_PRINCIPAL
    
    
    if estado_actual == MENU_PRINCIPAL:
        screen.blit(fondo, (0, 0))
        dibujar_texto("JUEGOS UNIFICADOS", font_large, WHITE, 400, 100)
        
        juego1_rect = dibujar_boton("Juego de Evasión", 400, 200, 300, 50, LIGHT_BLUE, BLUE, mouse_pos)
        juego2_rect = dibujar_boton("Juego de Recolección", 400, 280, 300, 50, LIGHT_BLUE, BLUE, mouse_pos)
        juego3_rect = dibujar_boton("Juego de Disparos", 400, 360, 300, 50, LIGHT_BLUE, BLUE, mouse_pos)
    
    elif estado_actual == MENU_SKIN:
        screen.blit(fondo, (0, 0))
        dibujar_texto("SELECCIONA UNA SKIN", font_large, WHITE, 400, 100)
        
        skin_rects = []
        for i in range(3):
            x = 200 + i * 200
            screen.blit(skins[i], (x - 25, 200))
            skin_rect = pygame.Rect(x - 25, 200, 50, 50)
            pygame.draw.rect(screen, WHITE if i == skin_seleccionada else BLACK, skin_rect, 2)
            skin_rects.append(skin_rect)
        
        volver_rect = dibujar_boton("Volver", 400, 400, 200, 50, LIGHT_BLUE, BLUE, mouse_pos)
    
    elif estado_actual == MENU_MUSICA:
        screen.blit(fondo, (0, 0))
        dibujar_texto("SELECCIONA UNA MÚSICA", font_large, WHITE, 400, 100)
        
        musica_rects = []
        for i in range(3):
            rect = dibujar_boton(f"Canción {i+1}", 400, 200 + i * 70, 250, 50, 
                               LIGHT_BLUE if i != musica_seleccionada else BLUE, 
                               BLUE, mouse_pos)
            musica_rects.append(rect)
        
        volver_rect = dibujar_boton("Volver", 400, 450, 200, 50, LIGHT_BLUE, BLUE, mouse_pos)
    
    elif estado_actual == MENU_JUEGO:
        screen.blit(fondo, (0, 0))
        nombre_juego = ["", "Evasión", "Recolección", "Disparos"][juego_seleccionado]
        dibujar_texto(f"DIFICULTAD - {nombre_juego}", font_large, WHITE, 400, 100)
        
        facil_rect = dibujar_boton("Fácil", 400, 200, 200, 50, LIGHT_BLUE, BLUE, mouse_pos)
        medio_rect = dibujar_boton("Medio", 400, 280, 200, 50, LIGHT_BLUE, BLUE, mouse_pos)
        dificil_rect = dibujar_boton("Difícil", 400, 360, 200, 50, LIGHT_BLUE, BLUE, mouse_pos)
        
        volver_rect = dibujar_boton("Volver", 400, 450, 200, 50, LIGHT_BLUE, BLUE, mouse_pos)
    
    elif estado_actual == JUGANDO:
        if juego_seleccionado == 1:
            juego_evasion()
        elif juego_seleccionado == 2:
            juego_recoleccion()
        elif juego_seleccionado == 3:
            juego_disparos()
    
    elif estado_actual == GAME_OVER:
        screen.blit(fondo, (0, 0))
        dibujar_texto("GAME OVER", font_large, RED, 400, 100)
        dibujar_texto(f"Puntuación: {puntuacion}", font_medium, WHITE, 400, 180)
        dibujar_texto(f"Intentos: {intentos}", font_medium, WHITE, 400, 230)
        
        jugar_rect = dibujar_boton("Jugar de nuevo", 400, 330, 250, 50, LIGHT_BLUE, BLUE, mouse_pos)
        menu_rect = dibujar_boton("Menú principal", 400, 400, 250, 50, LIGHT_BLUE, BLUE, mouse_pos)
    
    pygame.display.update()
    clock.tick(60)
