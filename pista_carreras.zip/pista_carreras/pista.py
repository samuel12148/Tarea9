import tkinter as tk
import time
import math

# Crear ventana
root = tk.Tk()
root.title("Pista de Carreras")
root.geometry("800x600")

# Crear lienzo
canvas = tk.Canvas(root, width=800, height=600, bg="gray20")
canvas.pack()

# Dibujar la pista (mínimo 4 curvas)
pista_coords = [
    (100, 500, 700, 500),
    (700, 500, 700, 100),
    (700, 100, 100, 100),
    (100, 100, 100, 500)
]

# Dibujar curvas con líneas
for i in range(len(pista_coords)):
    x1, y1, x2, y2 = pista_coords[i]
    canvas.create_line(x1, y1, x2, y2, width=40, fill="black")

# Crear un carro (rectángulo rojo)
carro = canvas.create_rectangle(80, 480, 120, 520, fill="red")

# Control simple: movimiento automático
dx, dy = 4, 0
punto = 0
puntos = [(700, 500), (700, 100), (100, 100), (100, 500)]

def mover_carro():
    global dx, dy, punto

    # Mover carro
    canvas.move(carro, dx, dy)
    pos = canvas.coords(carro)

    cx, cy = (pos[0] + pos[2]) / 2, (pos[1] + pos[3]) / 2
    tx, ty = puntos[punto]

    # Cambiar dirección en curvas
    if abs(cx - tx) < 10 and abs(cy - ty) < 10:
        punto = (punto + 1) % len(puntos)
        if punto == 0:
            dx, dy = 4, 0
        elif punto == 1:
            dx, dy = 0, -4
        elif punto == 2:
            dx, dy = -4, 0
        elif punto == 3:
            dx, dy = 0, 4

    root.after(30, mover_carro)

mover_carro()
root.mainloop()
