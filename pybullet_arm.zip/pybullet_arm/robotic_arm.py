import pybullet as p
import pybullet_data
import time
import math

# Conectar a PyBullet (modo GUI)
p.connect(p.GUI)
p.setGravity(0, 0, -9.8)
p.setAdditionalSearchPath(pybullet_data.getDataPath())

# Cargar un plano y el brazo KUKA incluido en PyBullet
planeId = p.loadURDF("plane.urdf")
robotId = p.loadURDF("kuka_iiwa/model.urdf", [0, 0, 0], useFixedBase=True)

# Mostrar número de articulaciones
num_joints = p.getNumJoints(robotId)
print("Número de articulaciones:", num_joints)

# Mover el brazo con un patrón senoidal simple
for t in range(2000):
    for joint in range(num_joints):
        target = 0.5 * math.sin(0.01 * t + joint)
        p.setJointMotorControl2(
            bodyIndex=robotId,
            jointIndex=joint,
            controlMode=p.POSITION_CONTROL,
            targetPosition=target,
            force=200
        )
    p.stepSimulation()
    time.sleep(1/240)

p.disconnect()

